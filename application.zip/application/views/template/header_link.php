<head>
  <title>
     <?php if (!empty($page_title)) echo $page_title;?>
  </title>
  <meta charset="UTF-8">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
    <!-- Font Awesome Icons -->
<link rel="stylesheet" href="<?php echo base_url();?>css/fontawesome-free/css/all.min.css">
<!-- Ionicons -->
<link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

<link href="<?php echo base_url();?>css/icheck-bootstrap/icheck-bootstrap.min.css" rel="stylesheet" type="text/css" media="all">

<link href="<?php echo base_url();?>css/overlayScrollbars/OverlayScrollbars.min.css" rel="stylesheet" type="text/css" media="all">
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" /> -->


<link href="<?php echo base_url();?>css/datatables-bs4/css/dataTables.bootstrap4.css" rel="stylesheet" type="text/css" media="all">

<link href="<?php echo base_url();?>css/custom_style.css" rel="stylesheet" type="text/css" media="all">

<link href="<?php echo base_url();?>css/adminlte.min.css" rel="stylesheet" type="text/css" media="all">
<!-- Google Font: Source Sans Pro -->
<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
 
</head> 


