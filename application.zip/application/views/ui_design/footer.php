 <footer>
            <div class="pt90 pb90 xs-pt50 xs-pb50 bg-color-dark1">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-12 col-12  xs-mb30">
                            <a href="#." class="mb15"><img class="footer-logo" src="img/logo/logo-grey.png" alt=""></a>
                        <p class="text-color-gray1 mb40">पदमश्री . डॉ .डी .वाय . पाटील सहकारी साखरकारखाना लि , ज्ञानशांतीनगरता . गगनबावडा , जि . कोल्हापूर हा कोल्हापूर पासून ५० किमी अंतरावर पश्चिमेकडील बाजूस स्थापित झालेला आहे .</p>
                            <div>
                                <a href="https://www.facebook.com/" class="social-btn social-btn-default mr5"><span class="fab fa-facebook-f social-btn-icon"></span></a>
                                <a href="https://twitter.com/" class="social-btn social-btn-default mr5 ml5"><span class="fab fa-twitter social-btn-icon"></span></a>
                                <a href="https://www.linkedin.com" class="social-btn social-btn-default mr5 ml5"><span class="fab fa-linkedin-in social-btn-icon"></span></a>
                                <a href="https://www.dribbble.com" class="social-btn social-btn-default mr5 ml5"><span class="fab fa-dribbble social-btn-icon"></span></a>
                                <a href="https://www.behance.net" class="social-btn social-btn-default mr5 ml5"><span class="fab fa-behance social-btn-icon"></span></a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12  pl45 pr15 xs-mb30 xs-pl15">
                            <p class="footer-menu-title text-color-gray4 mb15">Important Liks</p>
                            <ul class="link-list">
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">About us</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Portfolio</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Tender</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Financial Performance</a>
                                </li>

                                 <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Career</a>
                                </li>

                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12  pl45 pr15 xs-mb30 xs-pl15">
                            <p class="footer-menu-title text-color-gray4 mb15">Other Linkd</p>
                            <ul class="link-list">
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Payment Process</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Terms & Conditions</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Privacy Policy</a>
                                </li>
                                <li>
                                    <a href="#." class="text-color-gray1 hover-text-light mb10">Desclaimer</a>
                                </li>

                               
                            </ul>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12 col-12  pl45 pr15 xs-mb0 xs-pl15">
                            <p class="footer-menu-title text-color-gray4 mb15">Latest Portfolio</p>
                            <ul class="footer-portfolio">
                                <li>
                                    <a href="img/gallery/1.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/1.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                                <li>
                                    <a href="img/gallery/2.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/2.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                                <li>
                                    <a href="img/gallery/3.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/3.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                                <li>
                                    <a href="img/gallery/4.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/4.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                                <li>
                                    <a href="img/gallery/5.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/5.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                                <li>
                                    <a href="img/gallery/6.jpg" class="magnific_popup_link img_area">
                                        <img src="img/gallery/6.jpg" alt="">
                                        <div class="hover-overlay"></div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-color-dark2 pt50 pb50 xs-pt30 xs-pb30">
                <p class="text-color-black textCenter copyright-txt">Designed & Developed By Webisoftech</p>
            </div>
        </footer>