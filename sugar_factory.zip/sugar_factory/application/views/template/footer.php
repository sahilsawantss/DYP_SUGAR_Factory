 <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
   <!--  <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.2
    </div> -->
    <p>&copy 2021. All rights reserved | Design by <a href="http://www.webisoftech.com/">WEBiSOFTECH</a></p>
  </footer>

  <script> 
        setTimeout(function() {
            $('#alert').hide('fast');
        }, 2000);
    </script>