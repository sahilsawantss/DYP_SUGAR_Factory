
<script src="<?php echo base_url();?>js/jquery/jquery.min.js"></script>

<script src="<?php echo base_url();?>js/bootstrap/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo base_url();?>js/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>

<script src="<?php echo base_url();?>js/datatables/jquery.dataTables.js"></script>

<script src="<?php echo base_url();?>js/datatables-bs4/js/dataTables.bootstrap4.js"></script>

<script src="<?php echo base_url();?>js/bs-custom-file-input/bs-custom-file-input.min.js"></script>

<script src="<?php echo base_url();?>js/adminlte.js"></script>

<!-- <script src="<?php echo base_url();?>js/demo.js"></script> -->

<script src="<?php echo base_url();?>js/jquery-mousewheel/jquery.mousewheel.js"></script>

<script src="<?php echo base_url();?>js/raphael/raphael.min.js"></script>

<script src="<?php echo base_url();?>js/jquery-mapael/jquery.mapael.min.js"></script>

<script src="<?php echo base_url();?>js/jquery-mapael/maps/usa_states.min.js"></script>

<script src="<?php echo base_url();?>js/chart.js/Chart.min.js"></script>

<script src="<?php echo base_url();?>js/dashboard2.js"></script>

<script src="<?php echo base_url();?>js/bootbox.min.js"></script>

<script src="<?php echo base_url();?>js/preview.js"></script>

<script src="<?php echo base_url();?>js/jquery.validate.min.js"></script>

<script src="<?php echo base_url();?>js/form_validation.js"></script>

